
                                                     
              UNITED NATIONS ECONOMIC COMMISSION FOR EUROPE
             Trade and Sustainable Land Management Division
             Palais des Nations, CH-1211, Geneva, Switzerland
                 Tel:+41 22/917 1366 Fax:+41 22/917 0037
                     E-Mail: UNCEFACT(at)UNECE.ORG

           


                              UN/EDIFACT



                            D.12B DIRECTORY



                              2012-10-08


SOURCE: UN/CEFACT Bureau Programme Support (BPS)
STATUS: STANDARD

The directory and other Trade Facilitation Information is also available 
on the UNECE WorldWideWeb site, page: "www.uncefact.org"

License agreement for the use of 
UN/EDIFACT directories: read file licenagr.txt

------------------------------------------------------------------------

USAGE OF THE DISKETTE

- The file Validation12B.txt contains the Validation Team Statement for this
directory. 

- The file content.txt is the table of contents of the UN/EDIFACT Standard
 Directory.


- The files xxx.zip are compressed versions in ASCII (code page 
437 United States) of the UN Trade Data Interchange Directory using
the compression program PKZIP. The contents of Directory files is described 
in the file content.txt.

To get the decompressed version of the Directory, use the program pkunzip.exe 
stored on the diskette.

Type the commands:

 PKUNZIP [x:]xxx.ZIP       [y:][path]
 
  
 where
  x:      is the drive on which the diskette is stored
  y:      is the drive on which the decompressed version will be stored.
  path    specifies the path to the directory where the decompressed
          version will be stored.


-------------------------------------------------------------------
   PKUNZIP is a product of PKware:
      
      PKware, Inc.
      7545 North Port Washington Road
      Glendale, WI 53217-3422
      Fax: 414 352 3815

 PKUNZIP(tm) FAST! Extract Utility
 Copyright 1989 PKWARE Inc. All Rights Reserved

PKWARE, INC. HAS DONATED THE USE OF THE PKUNZIP(tm) DATA EXTRACTION
         UTILITY TO UNECE FOR USE WITH UNTDED AND UNTDID.

------------------------------------------------------------------
